import static org.junit.Assert.*;

import org.junit.Test;

public class abc {

	@Test
	public void testOpenAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAccountsAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testCloseAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchAccount() {
		fail("Not yet implemented");
	}

}
