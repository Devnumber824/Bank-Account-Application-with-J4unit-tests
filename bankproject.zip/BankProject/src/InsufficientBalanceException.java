

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception {

    public InsufficientBalanceException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public InsufficientBalanceException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}
