
@SuppressWarnings("serial")
public class InvalidAccountException extends Exception {

    public InvalidAccountException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public InvalidAccountException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}
